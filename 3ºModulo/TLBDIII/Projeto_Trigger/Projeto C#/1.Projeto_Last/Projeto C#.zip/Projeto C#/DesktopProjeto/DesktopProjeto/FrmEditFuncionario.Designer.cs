﻿namespace DesktopProjeto
{
    partial class FrmEditFuncionario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmEditFuncionario));
            this.chkGerente = new System.Windows.Forms.CheckBox();
            this.cmbDepartamentoFuncionario = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtSalarioFuncionario = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtTelefoneFuncionario = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtCidadeFuncionario = new System.Windows.Forms.TextBox();
            this.btnFinalizarEditFuncionario = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.txtNomeFuncionario = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // chkGerente
            // 
            this.chkGerente.AutoSize = true;
            this.chkGerente.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkGerente.ForeColor = System.Drawing.Color.DarkBlue;
            this.chkGerente.Location = new System.Drawing.Point(99, 348);
            this.chkGerente.Name = "chkGerente";
            this.chkGerente.Size = new System.Drawing.Size(95, 23);
            this.chkGerente.TabIndex = 45;
            this.chkGerente.Text = "Gerente";
            this.chkGerente.UseVisualStyleBackColor = true;
            // 
            // cmbDepartamentoFuncionario
            // 
            this.cmbDepartamentoFuncionario.Font = new System.Drawing.Font("MS Reference Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbDepartamentoFuncionario.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.cmbDepartamentoFuncionario.FormattingEnabled = true;
            this.cmbDepartamentoFuncionario.Items.AddRange(new object[] {
            "Comercial",
            "Jurídico",
            "Financeiro",
            "Tecnologia da informação",
            "Recursos Humanos",
            "Marketing",
            "Presidência"});
            this.cmbDepartamentoFuncionario.Location = new System.Drawing.Point(16, 301);
            this.cmbDepartamentoFuncionario.Name = "cmbDepartamentoFuncionario";
            this.cmbDepartamentoFuncionario.Size = new System.Drawing.Size(255, 24);
            this.cmbDepartamentoFuncionario.TabIndex = 44;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.DarkBlue;
            this.label6.Location = new System.Drawing.Point(12, 278);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(129, 19);
            this.label6.TabIndex = 43;
            this.label6.Text = "Departamento";
            // 
            // txtSalarioFuncionario
            // 
            this.txtSalarioFuncionario.Font = new System.Drawing.Font("MS Reference Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSalarioFuncionario.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.txtSalarioFuncionario.Location = new System.Drawing.Point(17, 247);
            this.txtSalarioFuncionario.Name = "txtSalarioFuncionario";
            this.txtSalarioFuncionario.Size = new System.Drawing.Size(256, 22);
            this.txtSalarioFuncionario.TabIndex = 42;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.DarkBlue;
            this.label5.Location = new System.Drawing.Point(14, 225);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(66, 19);
            this.label5.TabIndex = 41;
            this.label5.Text = "Salario";
            // 
            // txtTelefoneFuncionario
            // 
            this.txtTelefoneFuncionario.Font = new System.Drawing.Font("MS Reference Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTelefoneFuncionario.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.txtTelefoneFuncionario.Location = new System.Drawing.Point(16, 193);
            this.txtTelefoneFuncionario.Name = "txtTelefoneFuncionario";
            this.txtTelefoneFuncionario.Size = new System.Drawing.Size(256, 22);
            this.txtTelefoneFuncionario.TabIndex = 40;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.DarkBlue;
            this.label4.Location = new System.Drawing.Point(13, 171);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 19);
            this.label4.TabIndex = 39;
            this.label4.Text = "Telefone";
            // 
            // txtCidadeFuncionario
            // 
            this.txtCidadeFuncionario.Font = new System.Drawing.Font("MS Reference Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCidadeFuncionario.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.txtCidadeFuncionario.Location = new System.Drawing.Point(16, 140);
            this.txtCidadeFuncionario.Name = "txtCidadeFuncionario";
            this.txtCidadeFuncionario.Size = new System.Drawing.Size(256, 22);
            this.txtCidadeFuncionario.TabIndex = 38;
            // 
            // btnFinalizarEditFuncionario
            // 
            this.btnFinalizarEditFuncionario.BackColor = System.Drawing.Color.DarkBlue;
            this.btnFinalizarEditFuncionario.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFinalizarEditFuncionario.ForeColor = System.Drawing.Color.GhostWhite;
            this.btnFinalizarEditFuncionario.Location = new System.Drawing.Point(15, 393);
            this.btnFinalizarEditFuncionario.Name = "btnFinalizarEditFuncionario";
            this.btnFinalizarEditFuncionario.Size = new System.Drawing.Size(256, 41);
            this.btnFinalizarEditFuncionario.TabIndex = 37;
            this.btnFinalizarEditFuncionario.Text = "Salvar";
            this.btnFinalizarEditFuncionario.UseVisualStyleBackColor = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DarkBlue;
            this.label3.Location = new System.Drawing.Point(13, 118);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 19);
            this.label3.TabIndex = 36;
            this.label3.Text = "Cidade";
            // 
            // txtNomeFuncionario
            // 
            this.txtNomeFuncionario.Font = new System.Drawing.Font("MS Reference Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNomeFuncionario.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.txtNomeFuncionario.Location = new System.Drawing.Point(16, 86);
            this.txtNomeFuncionario.Name = "txtNomeFuncionario";
            this.txtNomeFuncionario.Size = new System.Drawing.Size(256, 22);
            this.txtNomeFuncionario.TabIndex = 35;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DarkBlue;
            this.label2.Location = new System.Drawing.Point(12, 64);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(142, 19);
            this.label2.TabIndex = 34;
            this.label2.Text = "Nome completo";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("MS Reference Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkBlue;
            this.label1.Location = new System.Drawing.Point(11, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(246, 29);
            this.label1.TabIndex = 33;
            this.label1.Text = "Editar Funcionario";
            // 
            // FrmEditFuncionario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(284, 444);
            this.Controls.Add(this.chkGerente);
            this.Controls.Add(this.cmbDepartamentoFuncionario);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtSalarioFuncionario);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtTelefoneFuncionario);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtCidadeFuncionario);
            this.Controls.Add(this.btnFinalizarEditFuncionario);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtNomeFuncionario);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmEditFuncionario";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Editar Funcionario";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox chkGerente;
        private System.Windows.Forms.ComboBox cmbDepartamentoFuncionario;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtSalarioFuncionario;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtTelefoneFuncionario;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtCidadeFuncionario;
        private System.Windows.Forms.Button btnFinalizarEditFuncionario;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtNomeFuncionario;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}
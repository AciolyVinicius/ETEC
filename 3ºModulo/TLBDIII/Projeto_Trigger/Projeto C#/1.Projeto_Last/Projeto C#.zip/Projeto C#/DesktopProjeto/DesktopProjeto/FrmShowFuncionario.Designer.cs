﻿namespace DesktopProjeto
{
    partial class FrmShowFuncionario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmShowFuncionario));
            this.chkGerente = new System.Windows.Forms.CheckBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblNomeFuncionario = new System.Windows.Forms.Label();
            this.lblCidadeFuncionario = new System.Windows.Forms.Label();
            this.lblTelefoneFuncionario = new System.Windows.Forms.Label();
            this.lblSalarioFuncionario = new System.Windows.Forms.Label();
            this.lblDepartamentoFuncionario = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // chkGerente
            // 
            this.chkGerente.AutoSize = true;
            this.chkGerente.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkGerente.ForeColor = System.Drawing.Color.DarkBlue;
            this.chkGerente.Location = new System.Drawing.Point(16, 63);
            this.chkGerente.Name = "chkGerente";
            this.chkGerente.Size = new System.Drawing.Size(95, 23);
            this.chkGerente.TabIndex = 45;
            this.chkGerente.Text = "Gerente";
            this.chkGerente.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.DarkBlue;
            this.label6.Location = new System.Drawing.Point(12, 317);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(129, 19);
            this.label6.TabIndex = 43;
            this.label6.Text = "Departamento";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.DarkBlue;
            this.label5.Location = new System.Drawing.Point(14, 264);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(66, 19);
            this.label5.TabIndex = 41;
            this.label5.Text = "Salario";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.DarkBlue;
            this.label4.Location = new System.Drawing.Point(13, 210);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 19);
            this.label4.TabIndex = 39;
            this.label4.Text = "Telefone";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DarkBlue;
            this.label3.Location = new System.Drawing.Point(13, 157);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 19);
            this.label3.TabIndex = 36;
            this.label3.Text = "Cidade";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DarkBlue;
            this.label2.Location = new System.Drawing.Point(12, 103);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(142, 19);
            this.label2.TabIndex = 34;
            this.label2.Text = "Nome completo";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("MS Reference Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkBlue;
            this.label1.Location = new System.Drawing.Point(11, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(162, 29);
            this.label1.TabIndex = 33;
            this.label1.Text = "Funcionario";
            // 
            // lblNomeFuncionario
            // 
            this.lblNomeFuncionario.AutoSize = true;
            this.lblNomeFuncionario.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomeFuncionario.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.lblNomeFuncionario.Location = new System.Drawing.Point(12, 124);
            this.lblNomeFuncionario.Name = "lblNomeFuncionario";
            this.lblNomeFuncionario.Size = new System.Drawing.Size(244, 19);
            this.lblNomeFuncionario.TabIndex = 46;
            this.lblNomeFuncionario.Text = "Matheus Guedes Saura Dino";
            // 
            // lblCidadeFuncionario
            // 
            this.lblCidadeFuncionario.AutoSize = true;
            this.lblCidadeFuncionario.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCidadeFuncionario.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.lblCidadeFuncionario.Location = new System.Drawing.Point(14, 177);
            this.lblCidadeFuncionario.Name = "lblCidadeFuncionario";
            this.lblCidadeFuncionario.Size = new System.Drawing.Size(108, 19);
            this.lblCidadeFuncionario.TabIndex = 47;
            this.lblCidadeFuncionario.Text = "São Vicente";
            // 
            // lblTelefoneFuncionario
            // 
            this.lblTelefoneFuncionario.AutoSize = true;
            this.lblTelefoneFuncionario.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTelefoneFuncionario.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.lblTelefoneFuncionario.Location = new System.Drawing.Point(14, 230);
            this.lblTelefoneFuncionario.Name = "lblTelefoneFuncionario";
            this.lblTelefoneFuncionario.Size = new System.Drawing.Size(160, 19);
            this.lblTelefoneFuncionario.TabIndex = 48;
            this.lblTelefoneFuncionario.Text = "(13) 93218-2315";
            // 
            // lblSalarioFuncionario
            // 
            this.lblSalarioFuncionario.AutoSize = true;
            this.lblSalarioFuncionario.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalarioFuncionario.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.lblSalarioFuncionario.Location = new System.Drawing.Point(14, 284);
            this.lblSalarioFuncionario.Name = "lblSalarioFuncionario";
            this.lblSalarioFuncionario.Size = new System.Drawing.Size(115, 19);
            this.lblSalarioFuncionario.TabIndex = 49;
            this.lblSalarioFuncionario.Text = "R$ 3.999,99";
            // 
            // lblDepartamentoFuncionario
            // 
            this.lblDepartamentoFuncionario.AutoSize = true;
            this.lblDepartamentoFuncionario.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDepartamentoFuncionario.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.lblDepartamentoFuncionario.Location = new System.Drawing.Point(12, 338);
            this.lblDepartamentoFuncionario.Name = "lblDepartamentoFuncionario";
            this.lblDepartamentoFuncionario.Size = new System.Drawing.Size(91, 19);
            this.lblDepartamentoFuncionario.TabIndex = 50;
            this.lblDepartamentoFuncionario.Text = "Marketing";
            // 
            // FrmShowFuncionario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(284, 444);
            this.Controls.Add(this.lblDepartamentoFuncionario);
            this.Controls.Add(this.lblSalarioFuncionario);
            this.Controls.Add(this.lblTelefoneFuncionario);
            this.Controls.Add(this.lblCidadeFuncionario);
            this.Controls.Add(this.lblNomeFuncionario);
            this.Controls.Add(this.chkGerente);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmShowFuncionario";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Funcionario";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblNomeFuncionario;
        private System.Windows.Forms.Label lblCidadeFuncionario;
        private System.Windows.Forms.Label lblTelefoneFuncionario;
        private System.Windows.Forms.Label lblSalarioFuncionario;
        private System.Windows.Forms.Label lblDepartamentoFuncionario;
        private System.Windows.Forms.CheckBox chkGerente;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DesktopProjeto
{
    public partial class FrmConcluirProjeto : Form
    {
        public FrmConcluirProjeto()
        {
            InitializeComponent();
        }

        private void btnConcluirProjeto_Click(object sender, EventArgs e)
        {
            //lstProjetoConcluido.Items.Add(lstProjetoAndamento.GetItemText(lstProjetoAndamento.Text));
            //lstProjetoAndamento.Items.RemoveAt(lstProjetoAndamento.SelectedIndex);
        }
    }
}

call  `3func`(298456511, 398569902, 1002225623);
call func_depart();
call func_depart_maiorque(980);
call projetos_funcionarios();
call func_dependente_filhoa();
call depart_cod(211);
call func_dependente();
call func_cidade_inicial('j');
call func_salario_maior_menor(970, 2501);
call proj_verb_indefinida_xbolsas(5);
call proj_verb_indefinida_xtipo('parcial');
call func_dependente_nao_filhoa();
call func_depart_gerenciam_em_projeto();

select * from departamento_projetos;
select * from funcionarios_projetos_horas;
select * from funcionarios_dependentes;
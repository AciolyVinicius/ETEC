/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exefelino;

/**
 *
 * @author Aluno
 */
public class Mamifero extends Animal {
    private int qtdMama;
    
    public int getQtdMama() {
        return qtdMama;
    }

    /**
     * @param qtdMama the qtdMama to set
     */
    public void setQtdMama(int qtdMama) {
        this.qtdMama = qtdMama;
    }   
}

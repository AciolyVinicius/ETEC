/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exefelino;

/**
 *
 * @author Aluno
 */
public class Felino extends Mamifero {

    private int garra;
    private int dente;
    private int bigode;
    
    /**
     * @return the garra
     */
    public int getGarra() {
        return garra;
    }

    /**
     * @param garra the garra to set
     */
    public void setGarra(int garra) {
        this.garra = garra;
    }

    /**
     * @return the dente
     */
    public int getDente() {
        return dente;
    }

    /**
     * @param dente the dente to set
     */
    public void setDente(int dente) {
        this.dente = dente;
    }

    /**
     * @return the bigode
     */
    public int getBigode() {
        return bigode;
    }

    /**
     * @param bigode the bigode to set
     */
    public void setBigode(int bigode) {
        this.bigode = bigode;
    }    
}

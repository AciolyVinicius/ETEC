/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exepaquiderme;

/**
 *
 * @author Aluno
 */
public class Paquiderme extends Mamifero{

    private float espessuraPele;
    
    public float getEspessuraPele() {
        return espessuraPele;
    }

    public void setEspessuraPele(float espessuraPele) {
        this.espessuraPele = espessuraPele;
    }
}

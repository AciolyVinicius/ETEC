/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exepaquiderme;

/**
 *
 * @author Aluno
 */
public class Mamifero extends Animal{

    private int qtdMama;
    private int poderReprodutor;
    
    public int getQtdMama() {
        return qtdMama;
    }

    public void setQtdMama(int qtdMama) {
        this.qtdMama = qtdMama;
    }

    public int getPoderReprodutor() {
        return poderReprodutor;
    }

    public void setPoderReprodutor(int poderReprodutor) {
        this.poderReprodutor = poderReprodutor;
    }    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package polimorfismo;

/**
 *
 * @author Aluno
 */
public class Cao extends Animal {
    public void comer(){
        System.out.println("O cão está comendo!");  
    }
}
